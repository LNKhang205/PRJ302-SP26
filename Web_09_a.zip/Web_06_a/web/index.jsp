<%-- 
    Document   : index
    Created on : Jan 19, 2026, 3:10:46 PM
    Author     : VNT
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <a href="login.jsp">login</a>
    </body>
</html>
